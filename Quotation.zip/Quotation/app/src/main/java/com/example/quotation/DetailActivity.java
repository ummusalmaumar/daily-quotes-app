package com.example.quotation;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_detail);

            TextView quoteTv = findViewById(R.id.detailQuoteText);
            TextView authorTv = findViewById(R.id.detailAuthorText);

            String quote = getIntent().getStringExtra("QUOTE_TEXT");
            String author = getIntent().getStringExtra("QUOTE_AUTHOR");

            quoteTv.setText(quote);
            authorTv.setText(author);
        }
    }

