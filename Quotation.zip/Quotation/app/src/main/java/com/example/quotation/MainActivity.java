package com.example.quotation;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        // 1. SET UP GRID (SCREEN 02)
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        // 2. ADD GRID DIVIDERS
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        List<Quote> quotes = new ArrayList<>();
        quotes.add(new Quote("Hunger never visits the home of a hard-working person; it only looks in through the window.", "Benjamin Franklin"));
        quotes.add(new Quote("Politics is too serious a matter to leave it in the hands of politicians.", "Charles De Gaulle"));
        quotes.add(new Quote("The Constitution should be the national inheritance, where people find both nourishment for the spirit and nourishment for the body.", "François Noël Babeuf"));
        quotes.add(new Quote("A pessimist is a well-informed optimist.", "Karel Čapek"));
        quotes.add(new Quote("Every day begins with a deep night.", "Bob Dylan"));
        quotes.add(new Quote("Music should ignite a flame in a man's heart and fill a woman's eyes with tears.", "Ludwig van Beethoven"));
        quotes.add(new Quote("Reason is our guide, but it often betrays us first.", "Vincent van Gogh"));
        quotes.add(new Quote("Everything worth doing is worth doing slowly.", "Gypsy Rose Lee"));
        quotes.add(new Quote("To desire friendship doesn't require much time, but friendship itself is a fruit that ripens slowly.", "Aristotle"));
        quotes.add(new Quote("What sleep is to the body, friendship is to the soul – it refreshes our strength.", "Cicero"));
        quotes.add(new Quote("To say that something exists, that it exists, and that something does not exist, that it does not exist, is truth.", "Aristotle"));
        quotes.add(new Quote("If you want people to talk about you, the only way is to do good.", "Voltaire"));
        quotes.add(new Quote("Taste and fashion restore everything to favor, except for what time has taken from us", "Margot Fonteyn"));
        quotes.add(new Quote("A nation may have one soul, one heart, one chest to expose, but woe to it if it has only one brain.", "Stanisław Jerzy Lec"));
        quotes.add(new Quote("If you are a dog and your owner offers you a stylish sweater – suggest a stylish tail instead.", "Fran Lebowitz"));
        quotes.add(new Quote("There is greater slavery where everything is agreed upon by everyone, than where nothing is agreed upon by anyone.", "Andrzej Maksymilian Fredro"));
        quotes.add(new Quote("Earthly music is a reflection of the music of the spheres.", "Pythagoras"));
        quotes.add(new Quote("As we grow older, we discover that the rarest thing is the courage to think.", "Anatole France"));
        quotes.add(new Quote("And youth doesn't like penny-pinching, it doesn’t turn every coin in its fingers.", "Ewa Szumańska"));
        quotes.add(new Quote("A pessimist is someone who, when faced with a choice between two evils, chooses both.", "Oscar Wilde"));
        quotes.add(new Quote("I am convinced that Christians only matter when they bring peace.", "Bob Dylan"));
        quotes.add(new Quote("Greater slavery exists where everything is agreed upon by everyone than where nothing is agreed upon by anyone.", "Andrzej Maksymilian Fredro"));
        quotes.add(new Quote("I am a slave to work and I take pride in it", "Nikos Kazantzakis"));
        quotes.add(new Quote("The jokes of the powerful are always witty", "William Shakespear"));
        quotes.add(new Quote("Reason is present only when people talk with one another.", "Hans Georg Gadamer"));
        quotes.add(new Quote("Optimism and pessimism differ only in the date of the end of the world.", "Stanisław Jerzy Lec"));
        quotes.add(new Quote("Sometimes we value someone too much to be able to love them.", "Immanuel Kant"));
        quotes.add(new Quote("Oh, if the suffering soul knew how loved it is by God, it would die of joy and excess happiness! One day we will know the value of suffering, but then we will no longer be able to suffer.", "Saint Faustina"));
        quotes.add(new Quote("For the government, before the elections, the voter is precious. After the elections, everything else becomes expensive.", "Jean Rigaux"));
        quotes.add(new Quote("Negative joy, the joy of knowing the opponent is wrong, characterizes small people, incapable of taking responsibility for the whole.", "Stefan Kisielewski"));
        quotes.add(new Quote("It is good to be famous, but it is surer to have money", "Seneca"));
        quotes.add(new Quote("When I paint – the ocean murmurs. Other painters splash around in hairdresser's water.", "BSalvador Dalí"));
        quotes.add(new Quote("By fighting against the elements, he overcomes the weakness of his muscles, conquers the struggle with a huge fish and the sea.", "Ernest Hemingway"));
        quotes.add(new Quote("Conscience does not prevent us from committing sins, but it prevents us from enjoying them.", "Salvador de Madariaga"));
        quotes.add(new Quote("Fashion that you cannot go out into the street wearing is not fashion.", "Coco Chanel"));
        quotes.add(new Quote("And the best writers are talkative.", "Luc De Vauvenargues."));
        quotes.add(new Quote("We men are so used to constantly eyeing women everywhere, that none of us approaches a young and handsome one without a secondary thought.", "Henryk Sienkiewicz"));
        quotes.add(new Quote("Often, suffering teaches people.", "Aesop"));
        quotes.add(new Quote("From time to time, one must sin, for otherwise, one loses the joy of virtue.", "Ilona Bodden"));
        quotes.add(new Quote("For those who suffer, even the smallest joy is happiness.", "Socrates"));
        quotes.add(new Quote("The greatest guilt is with those who do not want to listen to the truth..", "Cicero"));
        quotes.add(new Quote("For a woman to be happy, she cannot change men like she changes shirts.", "Honoré de Balzac"));
        quotes.add(new Quote("A man does not have friends; a man has only success.", "Napoleon Bonaparte"));
        quotes.add(new Quote("Silence is the second power in the world after speech.", "Jean Baptiste Henri Lacordaire"));
        quotes.add(new Quote("Time is money, and money is more than time.", "Edgar Allan Poe"));
        quotes.add(new Quote("Do not waste energy on things that cause worry, anxiety, and torment. Only one thing is needed: love God.", "Father Pio of Pietrelcina"));
        quotes.add(new Quote("The secret of life is not to do what you love, but to try to love what you have to do.", "Mulock Craik Dianh Maria"));
        quotes.add(new Quote("What a nonsense that suffering enriches us. We learn much more when we are happy.", "Françoise Sagan"));
        quotes.add(new Quote("Many people think they are thinking, while they are only changing prejudices.", "William James"));
        quotes.add(new Quote("Whatever I see or hear while fulfilling my duties as a physician, even outside the scope of my medical activities, that which does not need to be made public, I will keep in silence, never speaking of it to anyone.", "Hippocrates"));
        quotes.add(new Quote("Place all your worries about the future in God's hands and let Him lead you as a child.", "Teresa Benedicta of the Cross (Edith Stein)"));
        quotes.add(new Quote("Poetry is the abolition of all restrictions except those the author chooses to impose on himself. Poetry may perhaps be the last area of freedom.", "Mieczysław Jastrun"));
        quotes.add(new Quote("By fighting against the elements, he overcomes the weakness of his muscles, conquers the struggle with a huge fish and the sea.", "Ernest Hemingway"));
        quotes.add(new Quote("Who, except God, can give you peace? Has the world ever been able to satisfy the heart?", "Gerardo Majella"));



        adapter = new QuoteAdapter(quotes, new QuoteAdapter.OnQuoteClickListener() {
            @Override
            public void onQuoteClick(Quote quote) {
                // Launch DetailActivity when an item is clicked
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("QUOTE_TEXT", quote.getText());
                intent.putExtra("QUOTE_AUTHOR", quote.getAuthor());
                startActivity(intent);
            }
        });

        // 5. ATTACH ADAPTER
        recyclerView.setAdapter(adapter);
    }
}